# Approach 1
from IPL2020 import venue as dv # alias
from IPL2020.RCB import venue as rcbv
from IPL2020.KKR import venue as kkrv

dv.printVenue()
rcbv.printVenue()
kkrv.printVenue()

# Approach 2
from IPL2020.venue import printStadium as dSt
from IPL2020.KKR.venue import printStadium as KKRSt
from IPL2020.RCB.venue import printStadium as RCBSt

dSt()
KKRSt()
RCBSt()