# double underscore
# do-under
# __
# Internal to Python
# _