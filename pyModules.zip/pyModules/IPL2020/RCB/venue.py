def printVenue():
    print("RCB venue is Bangalore")


def printStadium():
    print("RCB stadium is Chinnaswamy Stadium")

