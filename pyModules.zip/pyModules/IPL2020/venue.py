def printVenue():
    print("Default venue is Mumbai")


def printStadium():
    print("Default stadium is Wankhade Stadium")

