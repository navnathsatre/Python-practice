def printVenue():
    print("KKR venue is Kolkotta")


def printStadium():
    print("KKR stadium is Eden Garden")

