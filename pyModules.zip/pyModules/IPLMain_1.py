# Approach 1
from IPL2020 import venue

venue.printVenue()
venue.printStadium()

# Approach 2
from IPL2020.venue import printStadium
printStadium()
