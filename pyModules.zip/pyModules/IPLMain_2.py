# Approach 1
from IPL2020.KKR import venue
venue.printVenue()
venue.printStadium()

# Approach 2
from IPL2020.KKR.venue import printStadium
printStadium()
