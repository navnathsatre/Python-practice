# import math
#
# print(math.factorial(5))

from math import factorial
print(factorial(10))

import math as mp # alias
print(mp.factorial(7))
