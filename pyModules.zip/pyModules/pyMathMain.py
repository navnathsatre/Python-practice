# Approach 1
# import pyMyMathModule
#
# pyMyMathModule.printRomanValue(2)

# Approach 2
from pyMyMathModule import printRomanValue
printRomanValue(3)